#ifndef SHORTLISTADAPTED_H
#define SHORTLISTADAPTED_H

#include "shortlist.h"

typedef shortLink link;

#endif // ! SHORTLISTADAPTED_H
